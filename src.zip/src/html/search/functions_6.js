var searchData=
[
  ['request_0',['Request',['../class_request.html#ad7005790f76440cc9a711cc7c81a6587',1,'Request::Request(string ipIn, string ipOut, int time)'],['../class_request.html#afaf8d8928de7ffff8a3767589489bd33',1,'Request::Request()']]]
];
