var searchData=
[
  ['id_0',['id',['../class_web_server.html#a02fff1dd9414d0fd6ff7960087b41038',1,'WebServer']]],
  ['ip_5fin_1',['ip_in',['../class_request.html#a2b93ebbd0fbd5ebf8b15f5583b087a12',1,'Request']]],
  ['ip_5fout_2',['ip_out',['../class_request.html#ae3394ea2aa8654ec22bc87083a8d3bda',1,'Request']]],
  ['isbusy_3',['isBusy',['../class_web_server.html#af3b6bd2cad6d8d476bc81bb6607eb75f',1,'WebServer']]]
];
