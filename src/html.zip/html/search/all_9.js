var searchData=
[
  ['tick_0',['tick',['../class_load_balancer.html#a86fb71fabe8ce27b1ce204b42466d76b',1,'LoadBalancer::tick()'],['../class_web_server.html#aa70cfd8749f4aee55c60e09a5f9211f7',1,'WebServer::tick()']]],
  ['time_1',['time',['../class_load_balancer.html#a363317f241373a9b71b03df5b4927265',1,'LoadBalancer']]],
  ['timeleft_2',['timeLeft',['../class_web_server.html#aa1f97e81a6c6a68373e597704fe93f2d',1,'WebServer']]]
];
