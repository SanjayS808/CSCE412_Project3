var searchData=
[
  ['tick_0',['tick',['../class_load_balancer.html#a86fb71fabe8ce27b1ce204b42466d76b',1,'LoadBalancer::tick()'],['../class_web_server.html#aa70cfd8749f4aee55c60e09a5f9211f7',1,'WebServer::tick()']]]
];
