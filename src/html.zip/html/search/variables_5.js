var searchData=
[
  ['time_0',['time',['../class_load_balancer.html#a363317f241373a9b71b03df5b4927265',1,'LoadBalancer']]],
  ['timeleft_1',['timeLeft',['../class_web_server.html#aa1f97e81a6c6a68373e597704fe93f2d',1,'WebServer']]]
];
